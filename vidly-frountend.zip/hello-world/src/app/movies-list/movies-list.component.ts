import { Component, OnInit } from '@angular/core';
import { Movie } from '../model/movie.model';
import { MovieServiceService } from '../services/movie-service.service';


@Component({
  selector: 'app-movies-list',
  templateUrl: './movies-list.component.html',
  styleUrls: ['./movies-list.component.css']
})
export class MoviesListComponent implements OnInit {

  public moviesList: any[];
  public errMessage: string;
  public hasError: boolean = false;

  constructor(private movieService: MovieServiceService) {
    // avoid writing API consume logic in constructor
    // // hhtpClient will call method get where we will pass API URL and we have to 
    // // subscribe it which will provide 3 property response, errorResponse & completion
    // // respone will give the body which we have tak in array form i.e response:Movie[]
    // // errorResponse if some error occur
    // // complete
    // // Note: As we want respone in array-list we have to write one paramater in get method i.e get<Movie[]
    // httpClient.get<Movie[]>('http://localhost:3900/api/movies')
    //           .subscribe(
    //             (response:Movie[]) => {
    //               console.log("Response Successfully recd. from server")
    //               console.log(response)
    //               this.moviesList = response;
    //             },
    //             (errorResponse:HttpErrorResponse) => {
    //               console.log('some error from the server..')
    //               console.log(errorResponse)
    //             }
    //           )
  }

  ngOnInit(): void {
    // fetch all movies from backend
    this.movieService.getAllMovies()
      .subscribe(
        (moviesData: Movie[]) => {
          this.moviesList = moviesData;
          this.hasError = false;
        },
        (error: string) => {
          this.hasError = true;
          this.errMessage = error;
        }
      )
  }

  // post: create new movie
  createMovie() {
    //create movie object manually and send it to server 
    const movie = { title: "new movie", numberInStock: 2, genreId: '5fa3c9b5f741cd1ba6d13038' }
    this.movieService.saveMovie(movie)
      .subscribe(
        (movie: Movie) => {
          //console.log('movie added to db;', movie)
          this.moviesList.unshift(movie);
        },
        (error: string) => {
          this.hasError = true;
          this.errMessage = error;
        }
      )
  }

  // put: update the existing movie
  updateMovie(movie) {
    movie.title = "updated title";
    this.movieService.saveMovie(movie)
      .subscribe(
        (updatedMovie: Movie) => {
          //console.log('movie updated...', updatedMovie)
          let index = this.moviesList.indexOf(movie);
          this.moviesList[index] = updatedMovie;
        },
        (error: string) => {
          this.hasError = true;
          this.errMessage = error;
        }
      )
  }

  // construct a delete request 
  deleteMovie(id) {
    this.movieService.deleteMovie(id)
      .subscribe(
        (movie: Movie) => {
          //console.log('movie deleted...', movie)
          let m = this.moviesList.find((item) => item._id == id)
          let index = this.moviesList.indexOf(m)
          this.moviesList.splice(index, 1);
          this.hasError = false;
        },
        (error: string) => {
          this.hasError = true;
          this.errMessage = error;
        }
      )
  }
}