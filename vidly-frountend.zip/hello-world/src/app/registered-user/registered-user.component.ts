import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registered-user',
  templateUrl: './registered-user.component.html',
  styleUrls: ['./registered-user.component.css']
})
export class RegisteredUserComponent implements OnInit {

  userForm = new FormGroup({
    username: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(10), Validators.pattern('[a-zA-z ]*')]),
    password: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]),
    name: new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(25), Validators.pattern('[a-zA-z ]*')]),
  });

  public get username(){
    return this.userForm.get('username')
  }

  public get password(){
    return this.userForm.get('password')
  }
  public get name(){
    return this.userForm.get('name')
  }

  constructor() { }

  ngOnInit(): void {
  }

  handleSubmit(){
    console.log('form submitted...')
    console.log(this.userForm)
  }

}
