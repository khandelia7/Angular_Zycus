import { Component, HostBinding, Input, OnInit } from '@angular/core';
import { Article } from './article.model';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})

// 5. Adding the Article Component
// 7. Creating the ArticleComponent Definition
export class ArticleComponent implements OnInit {

  // 8. a component host is the element this component is attached to
  @HostBinding('attr.class') cssClass = 'row'; // 9. store the properties on an instance of the Article class.
  @Input() article: Article; // 15. Configuring the ArticleComponent with inputs 
  
  constructor() {
    // this.article = new Article('Angular 2','http://angular.io',);
  }

  ngOnInit(): void {
  }

  // 9. two functions for voting
  // our browser is trying to follow the empty link, which tells the browser to reload.
  // will ensure the browser won’t try to refresh the page.
  // return a boolean value of false (tells the browser not to propagate the event upwards):
  voteUp(): boolean {
    this.article.voteUp(); // 12 point
    return false;
  }

  voteDown(): boolean {
    this.article.voteDown(); // 12 point
    return false;
  }
}
