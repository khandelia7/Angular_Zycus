import { Component } from '@angular/core';
import { Product } from './model/product.model';

@Component({ // decorator
  selector: 'app-root', // which tells Angular what element to matc
  templateUrl: './app.component.html', // which defines the view
  styleUrls: ['./app.component.css']
})

// 2. app.component.ts
// 4. Adding More Products
export class AppComponent {
  title = 'inventory-management';
  product: Product; // property product which is a Product object
  products: Product[];

  constructor() {
    this.product = new Product(
      "NICEHAT",
      "A Nice Black Hat", "/resources/images/products/black-hat.jpg", ["Men", "Accessories", "Hats"],
      29.99
    );

    this.products = [
      new Product(
        'MYSHOES',
        'Black Running Shoes', '/assets/images/products/black-shoes.jpg', ['Men', 'Shoes', 'Running Shoes'], 109.99),
      new Product(
        'NEATOJACKET',
        'Blue Jacket', '/assets/images/products/blue-jacket.jpg', ['Women', 'Apparel', 'Jackets & Vests'], 238.99),
      new Product(
        'NICEHAT',
        'A Nice Black Hat', '/assets/images/products/black-hat.jpg', ['Men', 'Accessories', 'Hats'],
        29.99)
    ];
  }

  // 5. Selecting a Product
  productWasSelected(product: Product): void {
    console.log('Product clicked: ', product);
  }

}
